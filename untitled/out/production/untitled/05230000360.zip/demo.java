import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import static java.lang.Double.parseDouble;
//tamamen çalışan düzgün kod !!!

//uyarı: kodun tamamen düzgün çalışması için inputQuiz1.txt dosyanızı sağ tıklayıp path(yol) olarak kopyalayıp
//152. satırda path name yazan yere(new File ın içine) yapıştırınız ve bir değil 2 tane ayraç(\\) olacak şekilde düzenleyiniz!
//örnek: "C:\\Users\\Talha Yusuf\\Desktop\\yazılım örnekler\\java örnekler\\untitled\\src\\inputQuiz1.txt"

//ayrıca inputQuiz.txt dosyasına  gireceğiniz girdileri lütfen şu formatta giriniz:
//Rectangle,4,5
//Circle,9
//lütfen başka şekilde dosyaya veri girmeyiniz(ekstra karakter,boşluk veya sözcük falan)!

class Rectangle {

    private double width;
    private double height;

    public Rectangle() {
        this(1, 1);
    }

    public Rectangle(double width, double height) {
        setWidth(width);
        setHeight(height);
        System.out.println("\nConstructed rectangle's width " + width + " and height " + height);
        System.out.println("Area = " + getArea());
        System.out.println("Perimeter = " + getPerimeter()+"\n");
    }

    public Rectangle(Rectangle rectangle) {
        this(rectangle.width, rectangle.height);
    }

    public double getWidth() {
        return width;
    }

    public void setWidth(double width) {
        if (width > 0) {
            this.width = width;
        } else {
            System.out.println("Width has to be positive.");
        }
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        if (height > 0) {
            this.height = height;
        } else {
            System.out.println("Height has to be positive.");
        }
    }

    public double getArea() {
        return width * height;
    }

    public double getPerimeter() {
        return 2 * (width + height);
    }

    @Override
    public String toString() {
        return "Rectangle's width = " + width + ", height = " + height;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof Rectangle)) {
            return false;
        }
        Rectangle other = (Rectangle) obj;
        return width == other.width && height == other.height;
    }
}





class Circle {
    private double radius;

    public Circle() {
        this(1);
    }

    public Circle(double radius) {
        setRadius(radius);
        System.out.println("\nConstructed circle and it's radius " + radius);

        System.out.println("Area = " + getArea());

        System.out.println("Perimeter = " + getPerimeter()+"\n");
    }

    public Circle(Circle other) {
        this(other.radius);
    }

    public double getRadius() {
        return radius;
    }

    public void setRadius(double radius) {
        if (radius > 0)
            this.radius = radius;
        else
            System.out.println("Radius has to be positive.");
    }

    public double getArea() {
        return Math.PI * radius * radius;
    }

    public double getPerimeter() {
        return 2 * Math.PI * radius;
    }

    @Override
    public String toString() {
        return "Circle's radius = " + radius;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == this)
            return true;
        if (!(obj instanceof Circle))
            return false;
        Circle other = (Circle) obj;
        return radius == other.radius;
    }
}


public class demo {

    public static void main(String[] args) throws IOException {
        FileReader fr;
        File file = new File("C:\\Users\\Talha Yusuf\\Desktop\\yazılım örnekler\\java örnekler\\untitled\\src\\inputQuiz1.txt");//buraya inputQuiz1.txt dosyasınızın path adresini kopyalayıp iki ayraçlı(\\) olacak şekilde düzenleyiniz!
        String[] lines = null;
        char data[] = new char[(int) file.length()];

        try {
            fr = new FileReader(file);
            fr.read(data);
            lines = new String(data).split("\n");
        } catch (FileNotFoundException e) {
            System.out.println("File isn't here." + e.getMessage());
        } catch (IOException e) {
            System.out.println("File not readable." + e.getMessage());
        }
        if(lines != null){
            for (String line : lines) {
                String[] shape = line.split(",");
                if(shape[0].toLowerCase().equals("rectangle")){
                    new Rectangle(parseDouble(shape[1]), parseDouble(shape[2]));
                }
                else if(shape[0].toLowerCase().equals("circle")){
                    new Circle(parseDouble(shape[1]));
                }
            }
        }
        Rectangle defaultrectangle = new Rectangle();
        defaultrectangle.setWidth(15);
        defaultrectangle.setHeight(10);

        Rectangle copyrectangle = new Rectangle(defaultrectangle);

        System.out.println("Are the two Rectangle objects equal?\n - " + defaultrectangle.equals(copyrectangle));
        System.out.println("Default Rectangle\n - " + defaultrectangle);
        System.out.println("Copy Rectangle\n - " + copyrectangle);
    }
}



